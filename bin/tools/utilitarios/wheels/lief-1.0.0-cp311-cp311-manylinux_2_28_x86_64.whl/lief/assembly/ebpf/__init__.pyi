import enum
from typing import Iterator, Optional, Union

from . import operands as operands
import lief.assembly


class OPCODE(enum.Enum):
    PHI = 0

    INLINEASM = 1

    INLINEASM_BR = 2

    CFI_INSTRUCTION = 3

    EH_LABEL = 4

    GC_LABEL = 5

    ANNOTATION_LABEL = 6

    KILL = 7

    EXTRACT_SUBREG = 8

    INSERT_SUBREG = 9

    IMPLICIT_DEF = 10

    INIT_UNDEF = 11

    SUBREG_TO_REG = 12

    COPY_TO_REGCLASS = 13

    DBG_VALUE = 14

    DBG_VALUE_LIST = 15

    DBG_INSTR_REF = 16

    DBG_PHI = 17

    DBG_LABEL = 18

    REG_SEQUENCE = 19

    COPY = 20

    COPY_LANEMASK = 21

    BUNDLE = 22

    LIFETIME_START = 23

    LIFETIME_END = 24

    PSEUDO_PROBE = 25

    ARITH_FENCE = 26

    STACKMAP = 27

    FENTRY_CALL = 28

    PATCHPOINT = 29

    LOAD_STACK_GUARD = 30

    PREALLOCATED_SETUP = 31

    PREALLOCATED_ARG = 32

    STATEPOINT = 33

    LOCAL_ESCAPE = 34

    FAULTING_OP = 35

    PATCHABLE_OP = 36

    PATCHABLE_FUNCTION_ENTER = 37

    PATCHABLE_RET = 38

    PATCHABLE_FUNCTION_EXIT = 39

    PATCHABLE_TAIL_CALL = 40

    PATCHABLE_EVENT_CALL = 41

    PATCHABLE_TYPED_EVENT_CALL = 42

    ICALL_BRANCH_FUNNEL = 43

    FAKE_USE = 44

    MEMBARRIER = 45

    JUMP_TABLE_DEBUG_INFO = 46

    RELOC_NONE = 47

    CONVERGENCECTRL_ENTRY = 48

    CONVERGENCECTRL_ANCHOR = 49

    CONVERGENCECTRL_LOOP = 50

    CONVERGENCECTRL_GLUE = 51

    G_ASSERT_SEXT = 52

    G_ASSERT_ZEXT = 53

    G_ASSERT_ALIGN = 54

    G_ADD = 55

    G_SUB = 56

    G_MUL = 57

    G_SDIV = 58

    G_UDIV = 59

    G_SREM = 60

    G_UREM = 61

    G_SDIVREM = 62

    G_UDIVREM = 63

    G_AND = 64

    G_OR = 65

    G_XOR = 66

    G_ABDS = 67

    G_ABDU = 68

    G_UAVGFLOOR = 69

    G_UAVGCEIL = 70

    G_SAVGFLOOR = 71

    G_SAVGCEIL = 72

    G_IMPLICIT_DEF = 73

    G_PHI = 74

    G_FRAME_INDEX = 75

    G_GLOBAL_VALUE = 76

    G_PTRAUTH_GLOBAL_VALUE = 77

    G_CONSTANT_POOL = 78

    G_EXTRACT = 79

    G_UNMERGE_VALUES = 80

    G_INSERT = 81

    G_MERGE_VALUES = 82

    G_BUILD_VECTOR = 83

    G_BUILD_VECTOR_TRUNC = 84

    G_CONCAT_VECTORS = 85

    G_PTRTOINT = 86

    G_INTTOPTR = 87

    G_BITCAST = 88

    G_FREEZE = 89

    G_CONSTANT_FOLD_BARRIER = 90

    G_INTRINSIC_FPTRUNC_ROUND = 91

    G_INTRINSIC_TRUNC = 92

    G_INTRINSIC_ROUND = 93

    G_INTRINSIC_LRINT = 94

    G_INTRINSIC_LLRINT = 95

    G_INTRINSIC_ROUNDEVEN = 96

    G_READCYCLECOUNTER = 97

    G_READSTEADYCOUNTER = 98

    G_LOAD = 99

    G_SEXTLOAD = 100

    G_ZEXTLOAD = 101

    G_INDEXED_LOAD = 102

    G_INDEXED_SEXTLOAD = 103

    G_INDEXED_ZEXTLOAD = 104

    G_STORE = 105

    G_INDEXED_STORE = 106

    G_ATOMIC_CMPXCHG_WITH_SUCCESS = 107

    G_ATOMIC_CMPXCHG = 108

    G_ATOMICRMW_XCHG = 109

    G_ATOMICRMW_ADD = 110

    G_ATOMICRMW_SUB = 111

    G_ATOMICRMW_AND = 112

    G_ATOMICRMW_NAND = 113

    G_ATOMICRMW_OR = 114

    G_ATOMICRMW_XOR = 115

    G_ATOMICRMW_MAX = 116

    G_ATOMICRMW_MIN = 117

    G_ATOMICRMW_UMAX = 118

    G_ATOMICRMW_UMIN = 119

    G_ATOMICRMW_FADD = 120

    G_ATOMICRMW_FSUB = 121

    G_ATOMICRMW_FMAX = 122

    G_ATOMICRMW_FMIN = 123

    G_ATOMICRMW_FMAXIMUM = 124

    G_ATOMICRMW_FMINIMUM = 125

    G_ATOMICRMW_UINC_WRAP = 126

    G_ATOMICRMW_UDEC_WRAP = 127

    G_ATOMICRMW_USUB_COND = 128

    G_ATOMICRMW_USUB_SAT = 129

    G_FENCE = 130

    G_PREFETCH = 131

    G_BRCOND = 132

    G_BRINDIRECT = 133

    G_INVOKE_REGION_START = 134

    G_INTRINSIC = 135

    G_INTRINSIC_W_SIDE_EFFECTS = 136

    G_INTRINSIC_CONVERGENT = 137

    G_INTRINSIC_CONVERGENT_W_SIDE_EFFECTS = 138

    G_ANYEXT = 139

    G_TRUNC = 140

    G_TRUNC_SSAT_S = 141

    G_TRUNC_SSAT_U = 142

    G_TRUNC_USAT_U = 143

    G_CONSTANT = 144

    G_FCONSTANT = 145

    G_VASTART = 146

    G_VAARG = 147

    G_SEXT = 148

    G_SEXT_INREG = 149

    G_ZEXT = 150

    G_SHL = 151

    G_LSHR = 152

    G_ASHR = 153

    G_FSHL = 154

    G_FSHR = 155

    G_ROTR = 156

    G_ROTL = 157

    G_ICMP = 158

    G_FCMP = 159

    G_SCMP = 160

    G_UCMP = 161

    G_SELECT = 162

    G_UADDO = 163

    G_UADDE = 164

    G_USUBO = 165

    G_USUBE = 166

    G_SADDO = 167

    G_SADDE = 168

    G_SSUBO = 169

    G_SSUBE = 170

    G_UMULO = 171

    G_SMULO = 172

    G_UMULH = 173

    G_SMULH = 174

    G_UADDSAT = 175

    G_SADDSAT = 176

    G_USUBSAT = 177

    G_SSUBSAT = 178

    G_USHLSAT = 179

    G_SSHLSAT = 180

    G_SMULFIX = 181

    G_UMULFIX = 182

    G_SMULFIXSAT = 183

    G_UMULFIXSAT = 184

    G_SDIVFIX = 185

    G_UDIVFIX = 186

    G_SDIVFIXSAT = 187

    G_UDIVFIXSAT = 188

    G_FADD = 189

    G_FSUB = 190

    G_FMUL = 191

    G_FMA = 192

    G_FMAD = 193

    G_FDIV = 194

    G_FREM = 195

    G_FMODF = 196

    G_FPOW = 197

    G_FPOWI = 198

    G_FEXP = 199

    G_FEXP2 = 200

    G_FEXP10 = 201

    G_FLOG = 202

    G_FLOG2 = 203

    G_FLOG10 = 204

    G_FLDEXP = 205

    G_FFREXP = 206

    G_FNEG = 207

    G_FPEXT = 208

    G_FPTRUNC = 209

    G_FPTOSI = 210

    G_FPTOUI = 211

    G_SITOFP = 212

    G_UITOFP = 213

    G_FPTOSI_SAT = 214

    G_FPTOUI_SAT = 215

    G_FABS = 216

    G_FCOPYSIGN = 217

    G_IS_FPCLASS = 218

    G_FCANONICALIZE = 219

    G_FMINNUM = 220

    G_FMAXNUM = 221

    G_FMINNUM_IEEE = 222

    G_FMAXNUM_IEEE = 223

    G_FMINIMUM = 224

    G_FMAXIMUM = 225

    G_FMINIMUMNUM = 226

    G_FMAXIMUMNUM = 227

    G_GET_FPENV = 228

    G_SET_FPENV = 229

    G_RESET_FPENV = 230

    G_GET_FPMODE = 231

    G_SET_FPMODE = 232

    G_RESET_FPMODE = 233

    G_GET_ROUNDING = 234

    G_SET_ROUNDING = 235

    G_PTR_ADD = 236

    G_PTRMASK = 237

    G_SMIN = 238

    G_SMAX = 239

    G_UMIN = 240

    G_UMAX = 241

    G_ABS = 242

    G_LROUND = 243

    G_LLROUND = 244

    G_BR = 245

    G_BRJT = 246

    G_VSCALE = 247

    G_INSERT_SUBVECTOR = 248

    G_EXTRACT_SUBVECTOR = 249

    G_INSERT_VECTOR_ELT = 250

    G_EXTRACT_VECTOR_ELT = 251

    G_SHUFFLE_VECTOR = 252

    G_SPLAT_VECTOR = 253

    G_STEP_VECTOR = 254

    G_VECTOR_COMPRESS = 255

    G_CTTZ = 256

    G_CTTZ_ZERO_UNDEF = 257

    G_CTLZ = 258

    G_CTLZ_ZERO_UNDEF = 259

    G_CTPOP = 260

    G_BSWAP = 261

    G_BITREVERSE = 262

    G_FCEIL = 263

    G_FCOS = 264

    G_FSIN = 265

    G_FSINCOS = 266

    G_FTAN = 267

    G_FACOS = 268

    G_FASIN = 269

    G_FATAN = 270

    G_FATAN2 = 271

    G_FCOSH = 272

    G_FSINH = 273

    G_FTANH = 274

    G_FSQRT = 275

    G_FFLOOR = 276

    G_FRINT = 277

    G_FNEARBYINT = 278

    G_ADDRSPACE_CAST = 279

    G_BLOCK_ADDR = 280

    G_JUMP_TABLE = 281

    G_DYN_STACKALLOC = 282

    G_STACKSAVE = 283

    G_STACKRESTORE = 284

    G_STRICT_FADD = 285

    G_STRICT_FSUB = 286

    G_STRICT_FMUL = 287

    G_STRICT_FDIV = 288

    G_STRICT_FREM = 289

    G_STRICT_FMA = 290

    G_STRICT_FSQRT = 291

    G_STRICT_FLDEXP = 292

    G_READ_REGISTER = 293

    G_WRITE_REGISTER = 294

    G_MEMCPY = 295

    G_MEMCPY_INLINE = 296

    G_MEMMOVE = 297

    G_MEMSET = 298

    G_BZERO = 299

    G_TRAP = 300

    G_DEBUGTRAP = 301

    G_UBSANTRAP = 302

    G_VECREDUCE_SEQ_FADD = 303

    G_VECREDUCE_SEQ_FMUL = 304

    G_VECREDUCE_FADD = 305

    G_VECREDUCE_FMUL = 306

    G_VECREDUCE_FMAX = 307

    G_VECREDUCE_FMIN = 308

    G_VECREDUCE_FMAXIMUM = 309

    G_VECREDUCE_FMINIMUM = 310

    G_VECREDUCE_ADD = 311

    G_VECREDUCE_MUL = 312

    G_VECREDUCE_AND = 313

    G_VECREDUCE_OR = 314

    G_VECREDUCE_XOR = 315

    G_VECREDUCE_SMAX = 316

    G_VECREDUCE_SMIN = 317

    G_VECREDUCE_UMAX = 318

    G_VECREDUCE_UMIN = 319

    G_SBFX = 320

    G_UBFX = 321

    ADJCALLSTACKDOWN = 322

    ADJCALLSTACKUP = 323

    FI_ri = 324

    LDIMM64 = 325

    MEMCPY = 326

    Select = 327

    Select_32 = 328

    Select_32_64 = 329

    Select_64_32 = 330

    Select_Ri = 331

    Select_Ri_32 = 332

    Select_Ri_32_64 = 333

    Select_Ri_64_32 = 334

    ADDR_SPACE_CAST = 335

    ADD_ri = 336

    ADD_ri_32 = 337

    ADD_rr = 338

    ADD_rr_32 = 339

    AND_ri = 340

    AND_ri_32 = 341

    AND_rr = 342

    AND_rr_32 = 343

    BE16 = 344

    BE32 = 345

    BE64 = 346

    BSWAP16 = 347

    BSWAP32 = 348

    BSWAP64 = 349

    CMPXCHGD = 350

    CMPXCHGW32 = 351

    CORE_LD32 = 352

    CORE_LD64 = 353

    CORE_SHIFT = 354

    CORE_ST = 355

    DIV_ri = 356

    DIV_ri_32 = 357

    DIV_rr = 358

    DIV_rr_32 = 359

    JAL = 360

    JALX = 361

    JCOND = 362

    JEQ_ri = 363

    JEQ_ri_32 = 364

    JEQ_rr = 365

    JEQ_rr_32 = 366

    JMP = 367

    JMPL = 368

    JNE_ri = 369

    JNE_ri_32 = 370

    JNE_rr = 371

    JNE_rr_32 = 372

    JSET_ri = 373

    JSET_ri_32 = 374

    JSET_rr = 375

    JSET_rr_32 = 376

    JSGE_ri = 377

    JSGE_ri_32 = 378

    JSGE_rr = 379

    JSGE_rr_32 = 380

    JSGT_ri = 381

    JSGT_ri_32 = 382

    JSGT_rr = 383

    JSGT_rr_32 = 384

    JSLE_ri = 385

    JSLE_ri_32 = 386

    JSLE_rr = 387

    JSLE_rr_32 = 388

    JSLT_ri = 389

    JSLT_ri_32 = 390

    JSLT_rr = 391

    JSLT_rr_32 = 392

    JUGE_ri = 393

    JUGE_ri_32 = 394

    JUGE_rr = 395

    JUGE_rr_32 = 396

    JUGT_ri = 397

    JUGT_ri_32 = 398

    JUGT_rr = 399

    JUGT_rr_32 = 400

    JULE_ri = 401

    JULE_ri_32 = 402

    JULE_rr = 403

    JULE_rr_32 = 404

    JULT_ri = 405

    JULT_ri_32 = 406

    JULT_rr = 407

    JULT_rr_32 = 408

    JX = 409

    LDB = 410

    LDB32 = 411

    LDBACQ32 = 412

    LDBSX = 413

    LDD = 414

    LDDACQ = 415

    LDH = 416

    LDH32 = 417

    LDHACQ32 = 418

    LDHSX = 419

    LDW = 420

    LDW32 = 421

    LDWACQ32 = 422

    LDWSX = 423

    LD_ABS_B = 424

    LD_ABS_H = 425

    LD_ABS_W = 426

    LD_IND_B = 427

    LD_IND_H = 428

    LD_IND_W = 429

    LD_imm64 = 430

    LD_pseudo = 431

    LE16 = 432

    LE32 = 433

    LE64 = 434

    MOD_ri = 435

    MOD_ri_32 = 436

    MOD_rr = 437

    MOD_rr_32 = 438

    MOVSX_rr_16 = 439

    MOVSX_rr_32 = 440

    MOVSX_rr_32_16 = 441

    MOVSX_rr_32_8 = 442

    MOVSX_rr_8 = 443

    MOV_32_64 = 444

    MOV_ri = 445

    MOV_ri_32 = 446

    MOV_rr = 447

    MOV_rr_32 = 448

    MUL_ri = 449

    MUL_ri_32 = 450

    MUL_rr = 451

    MUL_rr_32 = 452

    NEG_32 = 453

    NEG_64 = 454

    NOP = 455

    OR_ri = 456

    OR_ri_32 = 457

    OR_rr = 458

    OR_rr_32 = 459

    RET = 460

    SDIV_ri = 461

    SDIV_ri_32 = 462

    SDIV_rr = 463

    SDIV_rr_32 = 464

    SLL_ri = 465

    SLL_ri_32 = 466

    SLL_rr = 467

    SLL_rr_32 = 468

    SMOD_ri = 469

    SMOD_ri_32 = 470

    SMOD_rr = 471

    SMOD_rr_32 = 472

    SRA_ri = 473

    SRA_ri_32 = 474

    SRA_rr = 475

    SRA_rr_32 = 476

    SRL_ri = 477

    SRL_ri_32 = 478

    SRL_rr = 479

    SRL_rr_32 = 480

    STB = 481

    STB32 = 482

    STBREL32 = 483

    STB_imm = 484

    STD = 485

    STDREL = 486

    STD_imm = 487

    STH = 488

    STH32 = 489

    STHREL32 = 490

    STH_imm = 491

    STW = 492

    STW32 = 493

    STWREL32 = 494

    STW_imm = 495

    SUB_ri = 496

    SUB_ri_32 = 497

    SUB_rr = 498

    SUB_rr_32 = 499

    XADDD = 500

    XADDW = 501

    XADDW32 = 502

    XANDD = 503

    XANDW32 = 504

    XCHGD = 505

    XCHGW32 = 506

    XFADDD = 507

    XFADDW32 = 508

    XFANDD = 509

    XFANDW32 = 510

    XFORD = 511

    XFORW32 = 512

    XFXORD = 513

    XFXORW32 = 514

    XORD = 515

    XORW32 = 516

    XOR_ri = 517

    XOR_ri_32 = 518

    XOR_rr = 519

    XOR_rr_32 = 520

    XXORD = 521

    XXORW32 = 522

    INSTRUCTION_LIST_END = 523

class REG(enum.Enum):
    NoRegister = 0

    R0 = 1

    R1 = 2

    R2 = 3

    R3 = 4

    R4 = 5

    R5 = 6

    R6 = 7

    R7 = 8

    R8 = 9

    R9 = 10

    R10 = 11

    R11 = 12

    W0 = 13

    W1 = 14

    W2 = 15

    W3 = 16

    W4 = 17

    W5 = 18

    W6 = 19

    W7 = 20

    W8 = 21

    W9 = 22

    W10 = 23

    W11 = 24

    NUM_TARGET_REGS = 25

class Instruction(lief.assembly.Instruction):
    __match_args__: tuple = ...

    @property
    def opcode(self) -> OPCODE: ...

    @property
    def operands(self) -> Iterator[Optional[Operand]]: ...

class Operand:
    @property
    def to_string(self) -> str: ...

    def __str__(self) -> str: ...
